export type RouteType = 'produced-water' | 'freshwater';
export const WATER_HAULING: { readonly revision: 1; readonly packageId: 'water-hauling' };
export function rules(type?: RouteType | null): { operationSign: number; projectionSign: number; urgency: 'low' | 'high'; operation: 'pickup' | 'delivery' };
export function resultingLevel(type: RouteType | null | undefined, current: number, barrels: number, bblPerFoot: number, height: number): number | null;
export function projectedLevel(type: RouteType, level: number, asOf: string, at: string, dailyBbl: number | null | undefined, bblPerFoot: number, height: number): number | null;
export function inferredDailyBbl(type: RouteType, previousFeet: number, previousAt: string, currentFeet: number, currentAt: string, operationsBbl: number, bblPerFoot: number): number | null;
export function urgency(type: RouteType, level: number | null, threshold: number | null): 'unknown' | 'urgent' | 'normal';
