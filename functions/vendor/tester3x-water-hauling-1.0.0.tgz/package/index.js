'use strict';
// One package, one stored route type. Names and UI sections are never authority.
const WATER_HAULING = Object.freeze({
  revision: 1, packageId: 'water-hauling',
  'produced-water': Object.freeze({ operationSign: -1, projectionSign: 1, urgency: 'high', operation: 'pickup' }),
  freshwater: Object.freeze({ operationSign: 1, projectionSign: -1, urgency: 'low', operation: 'delivery' }),
});
function rules(type) {
  if (type == null) type = 'produced-water';
  if (type !== 'produced-water' && type !== 'freshwater') throw new Error('invalid_route_type');
  return WATER_HAULING[type];
}
function resultingLevel(type, current, barrels, bblPerFoot, height) {
  const rule = rules(type);
  if (![current, barrels, bblPerFoot, height].every(Number.isFinite) || current < 0 || barrels <= 0 || bblPerFoot <= 0 || height <= 0 || current > height) return null;
  const result = current + rule.operationSign * barrels / bblPerFoot;
  return result < -1e-6 || result > height + 1e-6 ? null : Math.max(0, Math.min(height, result));
}
function projectedLevel(type, level, asOf, at, dailyBbl, bblPerFoot, height) {
  const rule = rules(type), elapsed = Date.parse(at) - Date.parse(asOf);
  if (![level, elapsed, bblPerFoot, height].every(Number.isFinite) || elapsed < 0 || level < 0 || level > height || bblPerFoot <= 0 || height <= 0) return null;
  if (elapsed === 0) return level;
  if (dailyBbl == null || !Number.isFinite(dailyBbl) || dailyBbl < 0) return null;
  return Math.max(0, Math.min(height, level + rule.projectionSign * dailyBbl * elapsed / 86400000 / bblPerFoot));
}
function inferredDailyBbl(type, previousFeet, previousAt, currentFeet, currentAt, operationsBbl, bblPerFoot) {
  const rule = rules(type), elapsed = Date.parse(currentAt) - Date.parse(previousAt);
  if (![previousFeet, currentFeet, elapsed, operationsBbl, bblPerFoot].every(Number.isFinite) || elapsed <= 0 || operationsBbl < 0 || bblPerFoot <= 0) return null;
  const change = ((currentFeet - previousFeet) * bblPerFoot - rule.operationSign * operationsBbl) * rule.projectionSign;
  return change < -1e-6 ? null : Math.max(0, change) * 86400000 / elapsed;
}
function urgency(type, level, threshold) {
  const rule = rules(type);
  if (level == null || threshold == null || !Number.isFinite(level) || !Number.isFinite(threshold)) return 'unknown';
  return (rule.urgency === 'low' ? level <= threshold : level >= threshold) ? 'urgent' : 'normal';
}
module.exports = { WATER_HAULING, rules, resultingLevel, projectedLevel, inferredDailyBbl, urgency };
